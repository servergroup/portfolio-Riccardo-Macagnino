import { Image } from "expo-image";
import { Tabs } from "expo-router";
import React from "react";

import { useColorScheme } from "@/hooks/use-color-scheme";

export default function TabLayout() {
  const colorScheme = useColorScheme();

  return (
    <Tabs>
      <Tabs.Screen
        name="index"
        options={{
          title: "me",
          tabBarIcon: ({ focused }) => (
            <Image
              source={require("@/assets/images/foto.jpg")}
              style={{
                width: 32,
                height: 32,
                borderRadius: 50,
                borderWidth: focused ? 2 : 0,
                borderColor: focused ? "#4CAF50" : "transparent",
              }}
            />
          ),
        }}
      />

      <Tabs.Screen
        name="explore"
        options={{
          title: "Profilo",
          tabBarIcon: ({ focused }) => (
            <Image
              source={require("@/assets/images/profile.png")}
              style={{
                width: 32,
                height: 32,
                borderRadius: 50,
                opacity: focused ? 1 : 0.5,
              }}
            />
          ),
        }}
      />

      <Tabs.Screen
        name="prove"
        options={{
          title: "esercitazione",
          tabBarIcon: ({ focused }) => (
            <Image
              source={require("@/assets/images/technical-support.png")}
              style={{
                width: 32,
                height: 32,
                borderRadius: 50,
                opacity: focused ? 1 : 0.5,
              }}
            />
          ),
        }}
      />
    </Tabs>
  );
}
