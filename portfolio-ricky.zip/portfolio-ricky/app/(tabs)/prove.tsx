import ParallaxScrollView from "@/components/parallax-scroll-view";
import { ThemedView } from "@/components/themed-view";
import { ThemedText } from "@/components/themed-text";
import { Fonts } from "@/constants/theme";
import { useState } from "react";
import {
  Button,
  Image,
  Modal,
  Text,
  TextInput,
  View,
  StyleSheet,
} from "react-native";

export default function prove() {
  const [modal, setModal] = useState(false);

  // Dichiarazione variabili utilizzate nel form  di dichiarazione della sezone developer
  const [ruolo, setRuolo] = useState("");
  const [idCliente, setIdCliente] = useState(0);
  const [nome_progetto, setNome_progetto] = useState("");
  const [nome_developer, setNome_developer] = useState("");

  //  Dichiarazione variabili utilizzate nel form  di ddichiaazione della sezione cliente, ovvero  la richiesta di apertura dl progetto(vedere cimmenti in api spring)

  const [type_request, setType_request] = useState("");

  const [description, setDescription] = useState("");
  const [email, setEmail] = useState("");

  interface developer {
    id_client: Number;
    name_project: String;
    name_developer: String;
  }

  const developer_properties = {
    id_client: idCliente,
    name_project: nome_progetto,
    name_developer: nome_developer,
  };

  //for developer
  function addProject() {
    fetch("http://192.168.2.82:8089/developer/addProject", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(developer_properties),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Errore nella risposta del server");
        }
        return response.json();
      })
      .then((data) => {
        alert("Progetto salvato correttamente");
        console.log("Risposta server:", data);
      })
      .catch((error) => {
        alert("Problema con il server" + error);
        console.log(error);
      });
  }

  interface project {
    type_request: string;
    description: string;
    email: string;
    notice_developer: true;
  }

  const date_project = {
    type_request: type_request,
    description: description,
    email: email,
    notice_developer: true,
  };

  //for client
  function newProject() {
    fetch("http://192.168.2.82:8089/client/newProject", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(date_project),
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Errore nella risposta del server");
        }
        return response.json();
      })
      .then((data) => {
        alert("Progetto salvato correttamente");
        console.log("Risposta server:", data);
      })
      .catch((error) => {
        alert("Problema con il server" + error);
        console.log(error);
      });
  }

  return (
    <ParallaxScrollView
      headerImage={
        <Image
          source={require("@/assets/images/foto.jpg")}
          style={{ width: "100%", height: 250 }}
          resizeMode="cover"
        />
      }
      headerBackgroundColor={{
        dark: "blue",
        light: "blue",
      }}
    >
      <ThemedView>
        <ThemedText
          type="title"
          style={{
            fontFamily: Fonts.rounded,
          }}
        >
          GESTIONE PROGETTI
        </ThemedText>
        <Text></Text>

        <Text style={styles.p}>
          Questa sezine è dedicata ai progetti assegnatomi, attraverso tale
          sezione è possibile andare ad assegnarmi dei progetti da effettuare,
          oppure scirvieri come developer e contribuire con me{" "}
        </Text>
        <Text style={styles.p}>
          Il micoroservizio utilizzato per tale lavoro è java spring(Link per
          git in basso )
        </Text>

        <Text style={styles.p}>Scegli cosa sei</Text>
        <Text></Text>
        <Button
          title="Developer"
          onPress={() => {
            setRuolo("developer"), setModal(true);
          }}
        ></Button>
        <Text></Text>
        <Button
          title="Cliente"
          onPress={() => {
            setRuolo("cliente"), setModal(true);
          }}
        ></Button>

        <Modal visible={modal} animationType="slide">
          {ruolo === "developer" && (
            <View>
              <Text>Inerisci l'id del cliente del progetto assegnato</Text>
              <TextInput
                value={idCliente}
                onChangeText={setIdCliente}
                keyboardType="numeric"
              />
              <Text>Inserisci il nome del progetto assegnatosi</Text>
              <TextInput
                value={nome_progetto}
                onChangeText={(text) => setNome_progetto(text)}
              />
              <Text>Inserisci il nome del developer</Text>
              <TextInput
                value={nome_developer}
                onChangeText={(text) => setNome_developer(text)}
              />
              <Button title="Invia" onPress={() => addProject()}></Button>
              <Button title="chiudi" onPress={() => setModal(false)}></Button>
            </View>
          )}

          {ruolo === "cliente" && (
            <View>
              <Text>
                Inserisci il tipo di richiesta(sito,applicazione,microservizio)
              </Text>
              <TextInput
                value={type_request}
                onChangeText={(text) => setType_request(text)}
              />
              <Text>
                Inserisci la descrizione del progetto(requisiti essenzili,tempi
                di lavoro ,etc)
              </Text>
              <TextInput
                value={description}
                onChangeText={(text) => setDescription(text)}
              />

              <Text>Inserisci la tua mail</Text>
              <TextInput
                value={email}
                onChangeText={(text) => setEmail(text)}
              />
              <Button title="Invia" onPress={() => newProject()}></Button>
              <Button title="chiudi" onPress={() => setModal(false)}></Button>
            </View>
          )}
        </Modal>
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  p: {
    color: "white",
  },
  titleContainer: {
    flexDirection: "row",
    gap: 8,
    color: "white",
  },
});
