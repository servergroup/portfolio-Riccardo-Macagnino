import { Image } from "expo-image";
import {
  Modal,
  Platform,
  StyleSheet,
  Text,
  TouchableOpacity,
} from "react-native";

import { ExternalLink } from "@/components/external-link";
import ParallaxScrollView from "@/components/parallax-scroll-view";
import { ThemedText } from "@/components/themed-text";
import { ThemedView } from "@/components/themed-view";
import { Collapsible } from "@/components/ui/collapsible";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Fonts } from "@/constants/theme";
import { useState } from "react";

export default function TabTwoScreen() {
  const [photo, setPhoto] = useState("");
  const [modal, setModal] = useState(false);
  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: "#D0D0D0", dark: "#353636" }}
      headerImage={
        <IconSymbol
          size={310}
          color="#0aca71ff"
          name="chevron.left.forwardslash.chevron.right"
          style={styles.headerImage}
        />
      }
    >
      <ThemedView style={styles.titleContainer}>
        <ThemedText
          type="title"
          style={{
            fontFamily: Fonts.rounded,
          }}
        >
          SEZIONE CERTIFICAZIONI E CONTATTI
        </ThemedText>
      </ThemedView>
      <ThemedText>
        Nella seguente sezione ho riportato quelle che sono le mie
        certificazioni conseguite,i miei recapiti e le foto delle mie
        certificazioni.
      </ThemedText>
      <Collapsible title="File-based routing">
        <ThemedText>Certificazioni conseguite:</ThemedText>

        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/incendi.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/incendi.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text></Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>
        <Text></Text>

        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/dattilografia.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/dattilografia.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
        </TouchableOpacity>
        <Text></Text>
        <Text>
          Corso di prevenzione Antincendio,Click per maggiori dettagli
        </Text>
        <Text></Text>

        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/english_b1.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/english_b1.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text> </Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>

        <Text></Text>

        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/pekit.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/pekit.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text></Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>
        <Text></Text>

        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/soccorso_aziendale.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/soccorso_aziendale.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text></Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>
        <Text></Text>
        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/studio_medico.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/studio_medico.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text></Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>
        <Text></Text>
        <TouchableOpacity
          onPress={() => {
            setModal(true);
            setPhoto(
              require("@/assets/images/certificazioni_conseguite/yes i start up.png")
            );
          }}
        >
          <Image
            source={require("@/assets/images/certificazioni_conseguite/yes i start up.png")}
            style={{ width: 100, height: 100, alignSelf: "center" }}
          />
          <Text></Text>
          <Text>
            Corso di prevenzione Antincendio,Click per maggiori dettagli
          </Text>
        </TouchableOpacity>

        <Modal visible={modal} animationType="slide">
          <ThemedText
            onPress={() => {
              setModal(false);
            }}
            style={{ color: "black", fontSize: 16, fontWeight: "600" }}
          >
            Chiudi
          </ThemedText>
          <Image
            source={photo}
            style={{
              width: "200%",
              height: "50%",
              alignSelf: "center",
              marginTop: 150,
            }}
            resizeMode="contain"
          />
        </Modal>

        {/* <ExternalLink href="https://docs.expo.dev/router/introduction">
          <ThemedText type="link">Learn more</ThemedText>
        </ExternalLink>
      </Collapsible>
      <Collapsible title="Android, iOS, and web support">
        <ThemedText>
          You can open this project on Android, iOS, and the web. To open the web version, press{' '}
          <ThemedText type="defaultSemiBold">w</ThemedText> in the terminal running this project.
        </ThemedText> */}
      </Collapsible>
      <Collapsible title="Esperienze pregresse">
        <ThemedText>
          <Text>
            Ho lavorato come operatore call center presso Covisian Srl a
            Casarano. Inizialmente ero operativo nel reparto assicurazioni
            MetLife, dove mi occupavo di contattare potenziali clienti per
            proporre polizze assicurative.
          </Text>
          <Text>
            {" "}
            Successivamente sono passato al reparto Agos, dove contattavo i
            clienti per proporre offerte e soluzioni finanziarie della
            compagnia.
          </Text>
        </ThemedText>
      </Collapsible>

      <Collapsible title="esercitazione">
        <ExternalLink href="https://reactnative.dev/docs/images">
          <Text style={styles.p}>
            Per esercitarmi in maniera constante anche durante le vacanze ho
            deciso di creare un portfolio personale online seguito da un
            microservizio{"\n"}
          </Text>

          <ThemedText type="link">Learn more</ThemedText>
        </ExternalLink>
      </Collapsible>

      <Collapsible title="Contatti">
        <ThemedText>
          <Text style={styles.titleContainer}>I miei contatti</Text>
          <Text></Text>
        </ThemedText>
        <Text style={styles.p}> 📩Email:macagninoriccardo85@gmail.com</Text>
        <Text></Text>
        <Text style={styles.p}> 📞 +39 </Text>
        <Text style={styles.p}>3343706616</Text>
        {Platform.select({
          ios: <ThemedText></ThemedText>,
        })}
      </Collapsible>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  headerImage: {
    width: 250,
    height: 250,
    borderRadius: 12,
    alignSelf: "center",
    marginTop: 12,
  },
  titleContainer: {
    flexDirection: "row",
    gap: 8,
  },
  p: {
    color: "white",
  },
});
