import { Image } from "expo-image";
import { Platform, StyleSheet, Text, View } from "react-native";

import { HelloWave } from "@/components/hello-wave";
import ParallaxScrollView from "@/components/parallax-scroll-view";
import { ThemedText } from "@/components/themed-text";
import { ThemedView } from "@/components/themed-view";
import { Link } from "expo-router";

export default function HomeScreen() {
  return (
    <ParallaxScrollView
      headerBackgroundColor={{ light: "#A1CEDC", dark: "#1D3D47" }}
      headerImage={
        <Image
          source={require("@/assets/images/foto.jpg")}
          style={styles.reactLogo}
        />
      }
    >
      <ThemedView style={styles.titleContainer}>
        <ThemedText type="title">Salve a tutti</ThemedText>
        <HelloWave />
      </ThemedView>
      <ThemedView>
        <Text style={styles.p}>
          Mi chiamo Riccardo, ho 24 anni e vengo da Melissano, in provincia di
          Lecce. La mia più grande passione è l’informatica, in particolare lo
          sviluppo software. Attualmente sono un tirocinante developer e sto
          completando il percorso ITS presso Apulia Digital Maker,a Lecce, dove
          ho avuto modo di confrontarmi con docenti provenienti dal mondo
          aziendale. Durante la mia formazione ho studiato e utilizzato diversi
          linguaggi e tecnologie, tra cui:
          <View style={{ padding: 20 }}>
            <Text style={styles.elenco}>• Java (standard ed enterprise)</Text>
            <Text style={styles.elenco}>• c#(Standrd ed Enterprise)</Text>
            <Text style={styles.elenco}>• React </Text>
            <Text style={styles.elenco}>• TypeScript</Text>
            <Text style={styles.elenco}>• Html</Text>
            <Text style={styles.elenco}>• Css</Text>
            <Text style={styles.elenco}>• Javascript{"\n"}</Text>
          </View>
        </Text>
        <Text style={styles.p}>
          Ho approfondito anche la gestione dei database relazionali e non
          relazionali, lavorando con PostgreSQL e MongoDB. Successivamente ho
          studiato Docker, Git e le principali metodologie di project
          management, fino ad arrivare ai concetti introduttivi della
          blockchain. A breve inizierò un tirocinio in azienda: un’esperienza
          che non vedo l’ora di affrontare, perché mi permetterà di mettere in
          pratica tutto ciò che ho imparato finora.
        </Text>
        <Text></Text>
        <ThemedText type="title">PARLIAMO DI ME</ThemedText>
        <Text></Text>
        <Text style={styles.p}>
          Sono un ragazzo a cui piace molto provare nuove esperienze, ho
          frequentato l'istituto tecnico Alberghiero Filippo Bottazzi,a
          Ugento(Lecce).
        </Text>
        <Text style={styles.p}>
          Ho scelto di frequentare il percorso developer di ITS APULIA DIGITAL
          MAKER in quanto mi ha sempre appassionato il mondo
          dell'informatica,ritenevo fosse il percorso più idoneo da scegliere
          per cercare di trasformare la mia passione in un futuro lavoro. I miei
          hobby sono : l'informatica e la tecnologia,il calcio,gi amici,le serie
          tv e i film.
        </Text>

        <Text></Text>
        <Text></Text>
        <ThemedText type="title">PRIMA DELL'ITS</ThemedText>
        <Text style={styles.p}>
          Prima di intraprendere il percorso its ho frequentato diversi corsi di
          formazione, tra cui:
        </Text>
        <View style={{ padding: 20 }}>
          <Text style={styles.elenco}>
            • Segreteria di studio Medico - Garanzia Giovani
          </Text>
          {/*ok */}
          <Text style={styles.elenco}>• Pekit Expert - Garanzia Giovani</Text>
          {/*ok*/}
          <Text style={styles.elenco}>
            •Inglese Livello B1 - Garanzia Giovani
          </Text>
          {/*ok*/}
          <Text style={styles.elenco}>
            •Tecniche e Strategie di avvio di un'attività imprenditoriale -
            Garanzia Giovani
          </Text>
          {/*ok*/}
          <Text style={styles.elenco}>• Corso di Dattilografia-online</Text>
          {/*ok*/}
          <Text style={styles.elenco}>
            •Corso di Primo Soccorso - Istituto Alberghiero Filippo Bottazzi
          </Text>
          {/*ok*/}
          <Text style={styles.elenco}>
            •Corso di Prevenzione Antincendio - Istituto Alberghiero Filippo
            Bottazzi
          </Text>
          {/*ok*/}
        </View>
      </ThemedView>
    </ParallaxScrollView>
  );
}

const styles = StyleSheet.create({
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  stepContainer: {
    gap: 8,
    marginBottom: 8,
  },
  reactLogo: {
    height: 300,
    width: 380,
    bottom: 0,
    left: 0,
    position: "absolute",
  },

  p: {
    color: "white",
  },
  elenco: {
    fontSize: 18,
    color: "white",
  },
});
